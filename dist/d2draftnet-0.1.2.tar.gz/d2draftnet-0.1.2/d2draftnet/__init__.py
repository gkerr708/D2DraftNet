from .config import KEY, HERO_MAP

__all__ = ["KEY", "HERO_MAP"]